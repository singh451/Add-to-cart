<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;

class ProductController extends Controller
{
    public static $increment_val = 1;
    public function index()
    {
        $products = Product::all();
        //dd($products); exit;
        return view('products', compact('products'));
    }
    public function cart()
    {
        return view('cart');
    }
  
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function addToCart($id)
    {
        $product = Product::findOrFail($id);
          
        $cart = session()->get('cart', []);
  
        if(isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                "name" => $product->name,
                "quantity" => 1,
                "price" => $product->price,
                "image" => $product->image
            ];
        }
          
        session()->put('cart', $cart);
        return redirect()->back()->with('success', 'Product added to cart successfully!');
    }
  
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function update(Request $request)
    {
        if($request->id && $request->quantity){
            $cart = session()->get('cart');
            $cart[$request->id]["quantity"] = $request->quantity;
            session()->put('cart', $cart);
            session()->flash('success', 'Cart updated successfully');
        }
    }
  
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function remove(Request $request)
    {
        if($request->id) {
            $cart = session()->get('cart');
            if(isset($cart[$request->id])) {
                unset($cart[$request->id]);
                session()->put('cart', $cart);
            }
            session()->flash('success', 'Product removed successfully');
        }
    }
    /*public function array_q()
    {
    	$array = [
    		["name" => "player 01", "city" => "New Delhi"],
    		["name" => "player 02", "city" => "New Delhi"],
    		["name" => "player 03", "city" => "New Delhi"],
    		["name" => "player 04", "city" => "New Delhi"],
    		["name" => "player 05", "city" => "Gurgaon"],
    		["name" => "player 06", "city" => "Noida"],
    		["name" => "player 07", "city" => "Gurgaon"],
    		["name" => "player 08", "city" => "Noida"],
    		["name" => "player 09", "city" => "Gurgaon"],
    		["name" => "player 10", "city" => "New Delhi"],
    	];
    
    	foreach ($array as $key => $value) {
    		$new_array[$value['city']][] = $value['name'];
    	}

    	foreach ($new_array as $key => $value) {

    		foreach ($value as $key1 => $value1) {
    				
    				$main_array['name'] = $value1;
    				$main_array['city'] = $key;
    		}
    	}

		echo "<pre>"; print_r($main_array);	

    }*/

    public function array_q()
    {
    	
            	
        $array = [
    		["name" => "player 01", "city" => "New Delhi"],
    		["name" => "player 02", "city" => "New Delhi"],
    		["name" => "player 03", "city" => "New Delhi"],
    		["name" => "player 04", "city" => "Gurgaon"],
    		["name" => "player 05", "city" => "Gurgaon"],
    		["name" => "player 06", "city" => "Gurgaon"],
    		["name" => "player 07", "city" => "Noida"],
    		["name" => "player 08", "city" => "Noida"],
    		["name" => "player 09", "city" => "Noida"],
    		
    	];
    
    	foreach ($array as $key => $value) {
            $array_1[] = $value['city'];
        }
        $city_arr = array_unique($array_1);

        foreach ($city_arr as $key => $value) {
            $city_a[] = $value;
        }
    	
        /*
		foreach ($new_array as $key => $value) {
				$city_array[] = $key;
			}*/	
    	return 	$this->recursive($array,$city_a);
		
		
		
	}
	/*public function recursive($array)
	{
      for ($i=0; $i < count($array); $i++) { 
             for ($j=1; $j < count($array); $j++) { 
                 if($array[$i]['city']!=$array[$j]['city']){
                        
                        $final_arr[] = $array[$i];
                        $final_arr[] = $array[$j];
                         
                                    
                 }
                
             }
         }   

          echo "<pre>"; print_r(array_chunk($final_arr, 2)); exit;
               
    }*/
    public function recursive($array,$city_a)
    {

      for ($i=0; $i < count($array); $i++) { 
             for ($j=1; $j < count($array); $j++) { 
                 if($array[$i]['city']!=$array[$j]['city']){
                        
                        $final_arr[$array[$i]['city']][] = [$array[$i],$array[$j]];
                        //$final_arr[] = $array[$j];
                                       
                                    
                 }
                
             }
         }   
     
        $_SESSION['increment_val'] = 0;
        for ($i=0; $i < count($city_a); $i++) { 
            $rand = rand(0,count($final_arr[$city_a[$i]]));
            if(isset($final_arr[$city_a[$i]][$rand]))
            {
                $m_arr[$city_a[$i]] = $final_arr[$city_a[$i]][$rand];    
            }
                

        }
        echo "<a href='http://127.0.0.1:8000/array_q'><h1>Shuffle</h1> </a>";
        
        echo "<pre>"; print_r($m_arr);    

              
    }

}
