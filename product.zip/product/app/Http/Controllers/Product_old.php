<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;

class Product extends Controller
{

    public function index(){

    	$products = Product::all();
    	dd($products); exit;
    	return view('welcome');	
    }
    public function list(){
    	return view('list');	
    } 
}
