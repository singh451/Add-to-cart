;
<?php $__env->startSection('content'); ?>;


       
<div class="listing-section">
  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="product">
    <div class="image-box">
      <img src="<?php echo e($product->image); ?>" alt="">
    </div>
    <div class="text-box">
      <h2 class="item"><?php echo e($product->name); ?></h2>
      <h3 class="price"><?php echo e($product->price); ?></h3>
      <p class="description"><?php echo e($product->description); ?></p>
      <label for="item-1-quantity">Quantity:</label>
      <!-- <input type="text" name="item-1-quantity" id="item-1-quantity" value="1"> -->
      <p class="btn-holder"><a href="<?php echo e(route('add.to.cart', $product->id)); ?>" class="btn btn-warning btn-block text-center" role="button">Add to cart</a> </p>
    </div>
  </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\product\resources\views/welcome.blade.php ENDPATH**/ ?>