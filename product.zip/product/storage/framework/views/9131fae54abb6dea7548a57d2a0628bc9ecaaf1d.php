<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Page title -->
    <title>Demo</title>

    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <!--<link rel="shortcut icon" type="image/ico" href="favicon.ico" />-->

    <!-- Vendor styles -->
     <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(URL::asset('asset/styles/style.css')); ?>">
</head>
<body class="fixed-navbar">




<!-- Header -->






  

   

   <?php /**PATH D:\web\htdocs\breeze\resources\views/layouts/includes/header.blade.php ENDPATH**/ ?>