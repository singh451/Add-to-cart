@extends('layouts.includes.app');
@section('content');


       
<div class="listing-section">
  @foreach($products as $product)
  <div class="product">
    <div class="image-box">
      <img src="{{ $product->image }}" alt="">
    </div>
    <div class="text-box">
      <h2 class="item">{{ $product->name }}</h2>
      <h3 class="price">{{ $product->price }}</h3>
      <p class="description">{{ $product->description }}</p>
      <label for="item-1-quantity">Quantity:</label>
      <!-- <input type="text" name="item-1-quantity" id="item-1-quantity" value="1"> -->
      <p class="btn-holder"><a href="{{ route('add.to.cart', $product->id) }}" class="btn btn-warning btn-block text-center" role="button">Add to cart</a> </p>
    </div>
  </div>
    @endforeach
</div>



@stop