<!-- Footer-->
    <footer class="footer">
        <!-- <span class="pull-right">
            Example text
        </span>
        Company 2015-2020 -->
        

    </footer>

</div>

<!-- Vendor scripts -->
<script src="{{ URL::asset('asset/vendor/jquery/dist/jquery.min.js')}} "></script>

<!-- <script src="{{ URL::asset('asset/scripts/jscolor.js"></script> -->
<!--<script src="scripts/index.js"></script>-->


</body>
</html>