<!-- Navigation -->
<aside id="menu">
    <div id="navigation">
        <!-- <div class="profile-picture">
            <a href="index.html">
                <img src="images/profile.jpg" class="img-circle m-b" alt="logo">
            </a>

            <div class="stats-label text-color">
                <span class="font-extra-bold font-uppercase">Robert Razer</span>

                <div class="dropdown">
                    <a class="dropdown-toggle" href="#" data-toggle="dropdown">
                        <small class="text-muted">Founder of App <b class="caret"></b></small>
                    </a>
                    <ul class="dropdown-menu animated flipInX m-t-xs">
                        <li><a href="contacts.html">Contacts</a></li>
                        <li><a href="profile.html">Profile</a></li>
                        <li><a href="analytics.html">Analytics</a></li>
                        <li class="divider"></li>
                        <li><a href="login.html">Logout</a></li>
                    </ul>
                </div>


                <div id="sparkline1" class="small-chart m-t-sm"></div>
                <div>
                    <h4 class="font-extra-bold m-b-xs">
                        $260 104,200
                    </h4>
                    <small class="text-muted">Your income from the last year in sales product X.</small>
                </div>
            </div>
        </div> -->

        <?php
       
        $url = URL('/');
        
    
        ?>

        <div class="left side-menu">
            <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 600px;">
                <div class="sidebar-inner slimscrollleft" style="overflow: hidden; width: auto; height: 600px;">
                    <div id="sidebar-menu">
                        <ul class="nav" id="side-menu">
                            <li class=<?= ($url==''.URL('/').'dashboard' ? 'active' : '')?>>
                                <a href="<?= URL('/'); ?>"><i class="fa fa-home"></i> <span class="nav-label">Dashboard </span> <span class="label label-success pull-right"></span> </a>
                            </li>

                            <li class=<?= ($url==''.URL('/') || $url==''.URL('/').'upload' || $url==''.URL('/').'upload/listing'  ? 'active' : '')?>>
                                <a href="#"><i class="fa fa-shield"></i> <span class="nav-label">Actions</span><span class="fa arrow"></span> </a>
                                    <ul class="nav nav-second-level list-unstyled">
                                        <li class="<?= ($url==''.URL('/')  ? 'active' : '')?>">
                                            <a href="<?= URL('/'); ?>">Upload Document</a>
                                        </li>
                                        <li class="<?= ($url==''.URL('/').'upload/listing'  ? 'active' : '')?>"><a href="<?= URL('/') ?>upload/listing">Document Listing</a>
                                        </li>
                                    </ul>
                            </li>
                        </ul>

                    </div>
                </div>
            </div>
        </div>

    </div>
</aside>